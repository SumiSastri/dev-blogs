﻿using System;
using System.Collections.Generic;

namespace Week_10_Tutorial_Solution
{
    internal interface IGraph
    {
        string Name();
        int NumberOfVertices();
        bool AddEdge(int srcVertex, int destVertex);
        bool RemoveEdge(int srcVertex, int destVertex);
        bool IsAdjacent(int srcVertex, int destVertex);
        void Print();
    }

    internal interface IGraphTraversal : IGraph
    {
        // Perform a DFS traversal on the graph from vertex 0 & return the traversal path 
        List<int> DepthFirstSearch();

        // Perform a DFS traversal on the graph from vertex sv & return the traversal path 
        List<int> DepthFirstSearch(int sv);

        // Perform a BFS traversal on the graph from vertex 0 & return the traversal path 
        List<int> BreadthFirstSearch();

        // Perform a BFS traversal on the graph from vertex sv & return the traversal path 
        List<int> BreadthFirstSearch(int sv);

        // Print out a DFS or BFS traversal path 
        void PrintPath(List<int> path);
    }

    abstract class Graph : IGraph
    {
        private string graphName;
        private int cardVertices;
        private int[,] edges;

        protected int cardEdges = 0;  // updated when add or delete an edge

        public Graph(string graphName, int numberOfVertices)
        {
            this.graphName = graphName;
            this.cardVertices = numberOfVertices;
        }

        public Graph(string graphName, int numberOfVertices, int[,] edges)
        {
            this.graphName = graphName;
            this.cardVertices = numberOfVertices;
            this.edges = edges;
        }

        public string Name()
        {
            return graphName;
        }

        public int NumberOfVertices()
        {
            return cardVertices;
        }

        public void Print()
        {
            Console.WriteLine();
            Console.WriteLine("Graph: {0}, Card(V) = {1}, card(E) = {2}",
                              graphName, cardVertices, cardEdges);
            Console.WriteLine("Edges:");

            for (int sourceVertex = 0; sourceVertex < cardVertices; sourceVertex++)
            {
                for (int destinationVertex = 0; destinationVertex < cardVertices; destinationVertex++)
                {
                    if (IsAdjacent(sourceVertex, destinationVertex))
                    {
                        Console.WriteLine(sourceVertex + " --> " + destinationVertex);
                    }
                }
            }

            Console.WriteLine();
        }

        abstract public bool AddEdge(int sourceVertex, int destinationVertex);

        abstract public bool RemoveEdge(int sourceVertex, int destinationVertex);

        abstract public bool IsAdjacent(int sourceVertex, int destinationVertex);

        abstract public void PrintRepresentation();
    }

    class GraphAMTraversal : Graph, IGraphTraversal
    {
        private int[,] adjacencyMatrix;

        public GraphAMTraversal(string graphName, int numberOfVertices, int[,] edges)
            : base(graphName, numberOfVertices, edges)
        {
            adjacencyMatrix = new int[numberOfVertices, numberOfVertices];
            InitializeAdjacencyMatrix(edges);
        }

        private void InitializeAdjacencyMatrix(int[,] edges)
        {
            for (int i = 0; i < edges.GetLength(0); i++)
            {
                int src = edges[i, 0];
                int dest = edges[i, 1];
                adjacencyMatrix[src, dest] = 1; // Assuming unweighted graph
            }
        }

        public override bool AddEdge(int sourceVertex, int destinationVertex)
        {
            if (sourceVertex >= 0 && sourceVertex < NumberOfVertices() &&
                destinationVertex >= 0 && destinationVertex < NumberOfVertices())
            {
                adjacencyMatrix[sourceVertex, destinationVertex] = 1;
                cardEdges++;
                return true;
            }
            return false;
        }

        public override bool RemoveEdge(int sourceVertex, int destinationVertex)
        {
            if (sourceVertex >= 0 && sourceVertex < NumberOfVertices() &&
                destinationVertex >= 0 && destinationVertex < NumberOfVertices())
            {
                adjacencyMatrix[sourceVertex, destinationVertex] = 0;
                cardEdges--;
                return true;
            }
            return false;
        }

        public override bool IsAdjacent(int sourceVertex, int destinationVertex)
        {
            if (sourceVertex >= 0 && sourceVertex < NumberOfVertices() &&
                destinationVertex >= 0 && destinationVertex < NumberOfVertices())
            {
                return adjacencyMatrix[sourceVertex, destinationVertex] == 1;
            }
            return false;
        }

        public override void PrintRepresentation()
        {
            Console.WriteLine("Adjacency Matrix for Graph: " + Name());
            Console.WriteLine();

            Console.Write("  ");
            for (int dV = 0; dV < NumberOfVertices(); dV++)
            {
                Console.Write("  " + dV);
            }
            Console.WriteLine();
            Console.WriteLine();

            for (int sV = 0; sV < NumberOfVertices(); sV++)
            {
                Console.Write(sV + " ");

                for (int dV = 0; dV < NumberOfVertices(); dV++)
                {
                    Console.Write("  " + adjacencyMatrix[sV, dV]);
                }
                Console.WriteLine();
                Console.WriteLine();
            }
        }

        public List<int> DepthFirstSearch()
        {
            return DepthFirstSearch(0);
        }

        public List<int> DepthFirstSearch(int sv)
        {
            List<int> path = new List<int>();
            bool[] visited = new bool[NumberOfVertices()];
            DFS(sv, visited, path);
            return path;
        }

        private void DFS(int vertex, bool[] visited, List<int> path)
        {
            visited[vertex] = true;
            path.Add(vertex);

            for (int i = 0; i < NumberOfVertices(); i++)
            {
                if (adjacencyMatrix[vertex, i] == 1 && !visited[i])
                {
                    DFS(i, visited, path);
                }
            }
        }

        public List<int> BreadthFirstSearch()
        {
            return BreadthFirstSearch(0);
        }

        public List<int> BreadthFirstSearch(int sv)
        {
            List<int> path = new List<int>();
            bool[] visited = new bool[NumberOfVertices()];
            Queue<int> queue = new Queue<int>();

            visited[sv] = true;
            queue.Enqueue(sv);

            while (queue.Count > 0)
            {
                int vertex = queue.Dequeue();
                path.Add(vertex);

                for (int i = 0; i < NumberOfVertices(); i++)
                {
                    if (adjacencyMatrix[vertex, i] == 1 && !visited[i])
                    {
                        visited[i] = true;
                        queue.Enqueue(i);
                    }
                }
            }

            return path;
        }

        public void PrintPath(List<int> path)
        {
            Console.WriteLine("Traversal Path:");
            foreach (int vertex in path)
            {
                Console.Write(vertex + " ");
            }
            Console.WriteLine();
        }
    }

    class TestGraphTraversal
    {
        public static void Main(string[] args)
        {
            // Week 9 Graph
            const string name = "Week 9 Graph";
            const int NumberOfVertices = 8;

            int[,] Edges = new int[,] { { 0, 2 }, { 2, 0 },
                                        { 0, 4 }, { 4, 0 },
                                        { 1, 2 }, { 2, 1 },
                                        { 3, 1 }, { 1, 3 },
                                        { 1, 5 }, { 5, 1 },
                                        { 2, 4 }, { 4, 2 },
                                        { 2, 5 }, { 5, 2 },
                                        { 2, 6 }, { 6, 2 },
                                        { 3, 5 }, { 5, 3 },
                                        { 5, 6 }, { 6, 5 },
                                        { 5, 7 }, { 7, 5 },
                                        { 6, 7 }, { 7, 6 }
                                      };

            // Start DFS/BFS search from vertex:
            int startingVertex = 0;

            // Create the graph using an "Adjacency Matrix" representation
            Console.WriteLine();
            Console.WriteLine("Created graph using an Adjacency Matrix");
            Console.WriteLine();

            GraphAMTraversal graphAM = new GraphAMTraversal("W9G" + "-AM", NumberOfVertices, Edges);

            graphAM.Print();

            Console.WriteLine();
            Console.WriteLine();
            graphAM.PrintRepresentation();

            // DFS on the AM graph to find a suitable path from 0
            Console.WriteLine();
            Console.WriteLine("DFS on the Adjacency Matrix Graph from: 0");
            Console.WriteLine();

            startingVertex = 0;
            List<int> DFSpathAM_0 = graphAM.DepthFirstSearch(startingVertex);

            Console.WriteLine();
            Console.WriteLine("Depth First Search of : " + graphAM.Name() +
                               " from vertex: " + startingVertex);

            graphAM.PrintPath(DFSpathAM_0);

            // BFS on the AM graph to find a suitable path from 0
            Console.WriteLine();
            Console.WriteLine("BFS on the Adjacency Matrix Graph from: 0");
            Console.WriteLine();

            startingVertex = 0;
            List<int> BFSpathAM_0 = graphAM.BreadthFirstSearch(startingVertex);

            Console.WriteLine();
            Console.WriteLine("Breadth First Search of : " + graphAM.Name() +
                               " from vertex: " + startingVertex);

            graphAM.PrintPath(BFSpathAM_0);
        }
    }
}

/* result: 
 * Created graph using an Adjacency Matrix

Graph: W9G-AM, Card(V) = 8, card(E) = 24
Edges:
0 --> 2
0 --> 4
1 --> 2
1 --> 3
1 --> 5
2 --> 0
2 --> 1
2 --> 4
2 --> 5
2 --> 6
3 --> 1
3 --> 5
4 --> 0
4 --> 2
5 --> 1
5 --> 2
5 --> 3
5 --> 6
5 --> 7
6 --> 2
6 --> 5
6 --> 7
7 --> 5
7 --> 6

Adjacency Matrix for Graph: W9G-AM

  0  1  2  3  4  5  6  7

0 0  0  1  0  1  0  0  0
1 0  0  1  1  0  1  0  0
2 1  1  0  0  1  1  1  0
3 0  1  0  0  0  1  0  0
4 1  0  1  0  0  0  0  0
5 0  1  1  1  0  0  1  1
6 0  0  1  0  0  1  0  1
7 0  0  0  0  0  1  1  0

DFS on the Adjacency Matrix Graph from: 0

Depth First Search of : W9G-AM from vertex: 0
Traversal Path:
0 2 1 3 5 6 7 4 

BFS on the Adjacency Matrix Graph from: 0

Breadth First Search of : W9G-AM from vertex: 0
Traversal Path:
0 2 4 1 5 6 3 7 
*/