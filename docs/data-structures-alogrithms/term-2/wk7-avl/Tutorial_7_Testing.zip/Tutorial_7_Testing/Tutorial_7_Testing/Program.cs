﻿// Tutorial 7 

using System;

namespace Tutorial_7
{
    class TreeNode
    {

        public const TreeNode EMPTY_TREE = null;
        public const TreeNode NO_PARENT = null;

        private int data;
        private int height;

        private TreeNode leftChild, rightChild, parent;

        public TreeNode(int data)
        {
            this.data = data;
            height = 1;

            parent = NO_PARENT;

            leftChild = EMPTY_TREE;
            rightChild = EMPTY_TREE;
        }

        public TreeNode(int data, TreeNode parent)
        {
            this.data = data;
            height = 1;

            this.parent = parent;

            leftChild = EMPTY_TREE;
            rightChild = EMPTY_TREE;
        }


        public void setData(int data)
        {
            this.data = data;
        }

        public void setHeight(int height)
        {
            this.height = height;
        }

        public void setParent(TreeNode newP)
        {
            parent = newP;
        }

        public void setLeftChild(TreeNode newLC)
        {
            leftChild = newLC;

            if (newLC != EMPTY_TREE)
            {
                newLC.parent = this;
            }
        }

        public void setRightChild(TreeNode newRC)
        {
            rightChild = newRC;

            if (newRC != EMPTY_TREE)
            {
                newRC.parent = this;
            }
        }


        public int getData()
        {
            return data;
        }

        public int getHeight()
        {
            return height;
        }

        public TreeNode getParent()
        {
            return parent;
        }

        public TreeNode getLeftChild()
        {
            return leftChild;
        }

        public TreeNode getRightChild()
        {
            return rightChild;
        }


        public void print()
        {
            // print "NULL" if a variable is "null"

            string parentnode = (parent == NO_PARENT ?
                                        "NO_PARENT" : parent.getData().ToString());

            string leftchild = (leftChild == EMPTY_TREE ?
                                         "EMPTY_TREE" : leftChild.getData().ToString());

            string rightchild = (rightChild == EMPTY_TREE ?
                                           "EMPTY_TREE" : rightChild.getData().ToString());

            Console.WriteLine("TreeNode[ data = {0, -5}  height = {1, -5}      parent-- > { 2, -11}  leftChild-- > { 3, -12}rightChild-- > { 4, -12}]");
            Console.WriteLine( data + ",", height + ",",  parentnode + ",",  leftchild + ",", rightchild ) ;

        }

    } // TreeNode

    class BinarySearchTree
    {
        protected const TreeNode EMPTY_TREE = null;
        protected const TreeNode NO_PARENT = null;

        protected TreeNode root = EMPTY_TREE;
        protected int nodeCounter = 0;


        public int Size()
        {
            return nodeCounter;
        }


        public TreeNode findValueNode(int searchValue)
        {
            TreeNode currentNode = root;     // used to traverse tree

            while (currentNode != EMPTY_TREE)
            {
                if (currentNode.getData() == searchValue)
                {
                    return currentNode;
                }
                else
                {
                    if (currentNode.getData() < searchValue)
                    {
                        currentNode = currentNode.getRightChild();
                    }
                    else
                    {
                        currentNode = currentNode.getLeftChild();
                    }
                }
            }

            return null;   // value not found in tree
        }


        public void PrintRootNode()
        {


            if (root == EMPTY_TREE)
            {
                Console.Write("Root Node: EMPTY_TREE (NULL)");

            }
            else
            {
                Console.Write("Root Node:");
                root.print();
            }

        }


        /*
        * TO DO: print the contents of the tree in ascending order
        */
        public void Print()
        {
            if (root == EMPTY_TREE)
            {
                Console.WriteLine("Empty tree -- Node count = {0}", Size());
            }
            else
            {
                Console.WriteLine("Tree Node count = {0}", Size());
                PrintSubTree(root);
                Console.WriteLine();
            }
        }

        public void PrintSubTree(TreeNode n)
        {
            if (n != EMPTY_TREE)
            {
                PrintSubTree(n.getLeftChild());

                Console.Write(n.getData() + " ");

                PrintSubTree(n.getRightChild());
            }
        }

        public void PrintAllNodes()
        {
            if (root == EMPTY_TREE)
            {
                Console.WriteLine("Empty tree -- Node count = {0}", Size());
            }
            else
            {
                PrintAllNodes(root);
                Console.WriteLine("Node count = {0}", Size());

            }
        }

        public void PrintAllNodes(TreeNode root)
        {
            if (root == EMPTY_TREE)
            {
                return;   // nothing to do
            }
            else
            {
                root.print();

                PrintAllNodes(root.getLeftChild());

                PrintAllNodes(root.getRightChild());
            }
        }



        /*
        * TO DO: insert the new value, respecting the order
        * 
        * Version 2
        */


        // update root height 
        //  root.Height <-- 1 + max( root.getLeftChild().getHeight(), root.getRightChild.getHeight() ) 
        // root.setHeight( root.getHeight() 

        protected int calculateNodeHeight(TreeNode leftChild, TreeNode rightChild)
        {
            int leftChildHeight = 0;
            int rightChildHeight = 0;

            if (leftChild != EMPTY_TREE)
            {
                leftChildHeight = leftChild.getHeight();
            }

            if (rightChild != EMPTY_TREE)
            {
                rightChildHeight = rightChild.getHeight();
            }

            int maxChildHeight = (leftChildHeight > rightChildHeight ? leftChildHeight : rightChildHeight);

            int nodeHeight = 1 + maxChildHeight;

            return nodeHeight;
        }

        public void Insert(int newValue)
        {
            if (root == EMPTY_TREE)               // BST is an empty tree
            {
                root = new TreeNode(newValue);    // replace root with the new value node, finished
            }
            else
            {
                Insert(root, newValue);
            }

            nodeCounter++;
        }


        // Version 2
        protected void Insert(TreeNode root, int newValue)
        {
            if (newValue == root.getData())
            {
                // its a duplicate, so do nothing & finished
            }
            else
            {
                if (newValue < root.getData())
                {
                    if (root.getLeftChild() == EMPTY_TREE)
                    {
                        TreeNode newValueNode = new TreeNode(newValue, root);  // parent is root

                        root.setLeftChild(newValueNode);      // replace root with the new value node, finished
                    }
                    else
                    {
                        Insert(root.getLeftChild(), newValue);
                    }

                }
                else
                {
                    if (root.getData() < newValue)
                    {
                        if (root.getRightChild() == EMPTY_TREE)
                        {
                            TreeNode newValueNode = new TreeNode(newValue, root);  // parent is root

                            root.setRightChild(newValueNode);      // replace root with the new value node, finished
                        }
                        else
                        {
                            Insert(root.getRightChild(), newValue);
                        }

                    }
                }

                // update root height 
                // root.Height <-- 1 + max( root.getLeftChild().getHeight(), root.getRightChild.getHeight() ) 

                root.setHeight(calculateNodeHeight(root.getLeftChild(), root.getRightChild()));

            }

        }


        /*
        * Recursive auxiliary function: inserts the given value below the given node
        */
        private void insertBelow(TreeNode node, int value)
        {
            if (node.getData() < value)
            {
                if (node.getRightChild() == EMPTY_TREE)
                {
                    TreeNode newRightNode = new TreeNode(value);

                    node.setRightChild(newRightNode);
                }
                else
                    insertBelow(node.getRightChild(), value);
            }
            else
            {
                if (node.getLeftChild() == EMPTY_TREE)
                {
                    TreeNode newLeftNode = new TreeNode(value);

                    node.setLeftChild(newLeftNode);
                }
                else
                {
                    insertBelow(node.getLeftChild(), value);
                }
            }
        }

        /*
        * TO DO: find and remove the given value in case it is in the tree
        *
        * Function replaceNode below may be useful.
        */
        public void Delete(int value)
        {
            TreeNode currentNode = root;  // used to look for the value to delete

            while (currentNode != EMPTY_TREE && currentNode.getData() != value)
            {
                if (currentNode.getData() < value)
                    currentNode = currentNode.getRightChild();
                else
                    currentNode = currentNode.getLeftChild();
            }

            if (currentNode != EMPTY_TREE)  // value found, remove it
            {
                TreeNode delValueNode = currentNode;   // current node is the node to delete

                if (delValueNode.getLeftChild() == EMPTY_TREE)
                {
                    replaceNode(delValueNode, delValueNode.getRightChild());
                }
                else
                {
                    if (delValueNode.getRightChild() == EMPTY_TREE)
                    {
                        replaceNode(delValueNode, delValueNode.getLeftChild());
                    }
                    else
                    {
                        TreeNode maxLeftNode = delValueNode.getLeftChild();  // Search for the maximum value in the 
                                                                             // delValueNode's left sub-tree

                        while (maxLeftNode.getRightChild() != EMPTY_TREE)   // max value is on the far right of left sub-tree
                        {
                            maxLeftNode = maxLeftNode.getRightChild();
                        }

                        delValueNode.setData(maxLeftNode.getData());        // replace delete value with the max value

                        replaceNode(maxLeftNode, maxLeftNode.getLeftChild());
                    }

                }

                nodeCounter--;

            }
            else
            {
                Console.WriteLine("Deletion of node: {0} -- Failed, Not in Tree");
            }
        }

        /*
        * Auxiliary function: replaces a node
        * If node is the root, replacement becomes the new root
        * Otherwise, node is the left/right child of some parent, and replacement takes that place
        */
        private void replaceNode(TreeNode node, TreeNode replacement)
        {
            TreeNode parent = node.getParent();

            if (parent == NO_PARENT)
            {
                // node is the root 
                root = replacement;

                if (root != EMPTY_TREE)
                {
                    root.setParent(NO_PARENT);
                }

                // update root height 
                // root.Height <-- 1 + max( root.getLeftChild().getHeight(), root.getRightChild.getHeight() ) 

                root.setHeight(calculateNodeHeight(root.getLeftChild(), root.getRightChild()));

            }
            else
            {
                if (node == parent.getLeftChild())
                {
                    parent.setLeftChild(replacement);
                }
                else
                {
                    parent.setRightChild(replacement);
                }

                // update parent height 
                // parent.Height <-- 1 + max( parent.getLeftChild().getHeight(), parent.getRightChild.getHeight() ) 

                parent.setHeight(calculateNodeHeight(parent.getLeftChild(), parent.getRightChild()));

            }
        }


        /*
        * Inserts all the values in the given array
        */
        public void insertAll(int[] values, bool printResults)
        {
            for (int i = 0; i < values.Length; i++)
            {
                Insert(values[i]);
                if (printResults)
                {
                    Print();
                }

            }
        }

        /*
        * Removes all the values in the given array, if present
        */
        public void removeAll(int[] values, bool printResults)
        {
            for (int i = 0; i < values.Length; i++)
            {
                Delete(values[i]);

                if (printResults)
                    Print();
            }
        }


        //////////////////////  Treversal Algorithms ///////////////


        private const string INDENT = "    ";
        private string indentation = INDENT;

        protected void ProcessNode(TreeNode node)
        {
            Console.WriteLine(indentation + node.getData());
        }


        public void PreOrderTraversal()
        {
            PreOrderTraverse(root);
        }

        public void InOrderTraversal()
        {
            InOrderTraversal(root);
        }

        public void PostOrderTraversal()
        {
            PostOrderTraverse(root);
        }


        private void InOrderTraversal(TreeNode node)
        {
            String previous_indentation = indentation;

            // increase indentation for this level 
            indentation = indentation + INDENT;

            if (node == null)
            {
                Console.WriteLine(indentation + "EMPTY TREE");
            }
            else
            {
                InOrderTraversal(node.getLeftChild());

                ProcessNode(node);

                InOrderTraversal(node.getRightChild());
            }

            // reset indentation
            indentation = previous_indentation;

        }

        // Ex 5.3  Trace recursive calls for InOrder traversal

        public void TraceInOrderTraverse(TreeNode node)
        {
            string previous_indentation = indentation;

            // increase indentation for this level 
            indentation = indentation + INDENT;

            if (node == null)
            {
                Console.WriteLine(indentation + "Subtree is EMPTY");
            }
            else
            {
                Console.WriteLine(indentation + "Start Processing Tree with root: " + node.getData());

                Console.WriteLine(indentation + "InOrder Traverse LEFT subtree of node: " + node.getData());
                TraceInOrderTraverse(node.getLeftChild());

                Console.WriteLine(indentation + "Process Node: " + node.getData());
                // ProcessNode( node ) ;

                Console.WriteLine(indentation + "InOrder Traverse RIGHT subtree of node: " + node.getData());
                TraceInOrderTraverse(node.getRightChild());

                Console.WriteLine(indentation + "Finished processing Tree with root: " + node.getData());
            }

            // reset indentation
            indentation = previous_indentation;

        }

        /* 
           Week 5 Lecture, slide 9
        */

        public void PreOrderTraverse(TreeNode node)
        {
            String previous_indentation = indentation;

            // increase indentation for this level 
            indentation = indentation + INDENT;

            if (node == null)
            {
                Console.WriteLine(indentation + "EMPTY Tree");
            }
            else
            {
                ProcessNode(node);

                PreOrderTraverse(node.getLeftChild());

                PreOrderTraverse(node.getRightChild());
            }

            // reset indentation
            indentation = previous_indentation;

        }


        /* 
           Week 5 Lecture, slide 9
        */

        public void PostOrderTraverse(TreeNode node)
        {
            String previous_indentation = indentation;

            // increase indentation for this level 
            indentation = indentation + INDENT;

            if (node == null)
            {
                Console.WriteLine(indentation + "EMPTY Tree");
            }
            else
            {
                PostOrderTraverse(node.getLeftChild());

                PostOrderTraverse(node.getRightChild());

                ProcessNode(node);
            }

            // reset indentation
            indentation = previous_indentation;

        }

    }//




    class BST_Properties : BinarySearchTree
    {

        public BST_Properties() : base()
        {
            Console.WriteLine("Created a Traversable BST ");
        }



        /* 
            Ex 7.2 Tree Height
            Week 7 Lecture, slide 18, based on Post Order traversal
        */

        public int Height()
        {
            return height(root);
        }

        private int height(TreeNode node)
        {
            if (node == EMPTY_TREE)
            {
                return 0;
            }
            else
            {
                int leftHeight = height(node.getLeftChild());

                int rightHeight = height(node.getRightChild());

                return (1 + (leftHeight > rightHeight ? leftHeight : rightHeight));
            }
        }


        /* 
          Ex 7.2 Tree Node Levels
          Week 7 Lecture, based on PreOrder traversal
        */

        private const string INDENT = "    ";
        private string indentation = INDENT;


        public void PrintNodeLevels()
        {
            nodeLevel(root, 0);
        }


        private void nodeLevel(TreeNode node, int level)
        {
            string previous_indentation = indentation;

            // increase indentation for this level 
            indentation = indentation + INDENT;

            if (node == null)
            {
                // Console.WriteLine( indentation + "EMPTY Tree" ) ;
            }
            else
            {
                Console.WriteLine(indentation + "Node: " + node.getData()
                                              + ",  Level: " + level);

                nodeLevel(node.getLeftChild(), level + 1);

                nodeLevel(node.getRightChild(), level + 1);
            }

            // reset indentation
            indentation = previous_indentation;
        }


        public int UpdateHeight()
        {
            return updateHeight(root);  // height of the tree
        }


        private int updateHeight(TreeNode node)
        {
            if (node == EMPTY_TREE)
            {
                return 0;
            }
            else
            {
                int leftHt = updateHeight(node.getLeftChild());

                int leftHeight;

                if (node.getLeftChild() != EMPTY_TREE)
                {
                    leftHeight = node.getLeftChild().getHeight();
                }
                else
                {
                    leftHeight = 0;
                }


                int rightHt = updateHeight(node.getRightChild());

                int rightHeight;

                if (node.getRightChild() != EMPTY_TREE)
                {
                    rightHeight = node.getRightChild().getHeight();
                }
                else
                {
                    rightHeight = 0;
                }


                int maxSubTreeHeight = (leftHeight > rightHeight ? leftHeight : rightHeight);

                int treeHeight = 1 + maxSubTreeHeight;

                node.setHeight(treeHeight);

                return treeHeight;
            }
        }



    } // class BST_Properties















    class Tutorial_7_Testing
    {
        static void Main(string[] args)
        {


            /////////////////////////////////////////////////////////////////
            Console.WriteLine();
            Console.WriteLine("Lecture 5 - Binary Search Trees ");
            Console.WriteLine();
            /////////////////////////////////////////////////////////////////



            // Whether to print results. Only use with small numbers of values.
            bool printResults = false;


            /////////////////////////////////////////////////////////////////
            Console.WriteLine();
            Console.WriteLine("Testing Binary Search Trees Operations");
            Console.WriteLine();
            /////////////////////////////////////////////////////////////////


            ////////////////////////////////////////////////////////////
            // Set up test data for a BST 
            ////////////////////////////////////////////////////////////

            // Use random numbers & how many values to generate:
            int quantity = 10;
            // int[] numbers = randomValues( quantity );


            int[] treeA = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55 };

            int[] treeB = { 55, 50, 45, 40, 35, 30, 25, 20, 15, 10, 5 };

            int[] treeC = { 30, 25, 20, 15, 10, 5, 35, 40, 45, 50, 55 };

            int[] treeD = { 30, 15, 45, 10, 40, 20, 50, 5, 35, 25, 55 };


            int[] numbers = treeC;

            int[] deleteNumbers = { 10, 45, 30 };

            ////////////////////////////////////////////////////////////
            // Create a BST & test operations on it
            ////////////////////////////////////////////////////////////

            // BinarySearchTree bstTree = new BinarySearchTree();

            BST_Properties bstTree = new BST_Properties();

            bstTree.Print();
            Console.WriteLine();

            Console.Write("Insert Values into BST: ");
            Console.WriteLine();

            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write("Insert value: {0}", numbers[i]);
                Console.WriteLine();

                bstTree.Insert(numbers[i]);

                // bstTree.UpdateHeight() ;

                bstTree.PrintAllNodes();

                Console.WriteLine();
                Console.WriteLine();

            }
            Console.WriteLine();


            // Print Tree Height

            int treeheight = bstTree.Height();

            Console.Write("BST height = {0}", treeheight);
            Console.WriteLine();

            bstTree.PrintNodeLevels();

            Console.WriteLine();

            /////////////////  Treversal //////////////////



            ///////////////////  Deletion of : 10, 45, 30 ////////////////

            Console.WriteLine();
            Console.Write("Delete Values from BST: ");
            Console.WriteLine();

            for (int i = 0; i < deleteNumbers.Length; i++)
            {
                Console.Write("Delete value: {0}", deleteNumbers[i]);
                Console.WriteLine();

                bstTree.Delete(deleteNumbers[i]);

                // bstTree.UpdateHeight();

                bstTree.PrintAllNodes();

                Console.WriteLine();
                Console.WriteLine();

            }
            Console.WriteLine();

            //////////////////////////////////////////////////////////
            // Print Tree Height

            treeheight = bstTree.Height();

            Console.Write("BST height = {0}", treeheight);
            Console.WriteLine();

            bstTree.PrintNodeLevels();

            Console.WriteLine();

        } // Main


    } // Tutorial_7_Testing

} // Tutorial_7 

